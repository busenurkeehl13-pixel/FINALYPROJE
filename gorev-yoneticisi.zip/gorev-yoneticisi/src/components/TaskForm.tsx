import { useState } from "react";
export default function TaskForm({ onAdd }: { onAdd: (t: string) => void }) {
  const [text, setText] = useState("");
  const submit = () => { if (!text.trim()) return; onAdd(text.trim()); setText(""); };
  return (
    <div className="row">
      <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder="Yeni görev yaz..." />
      <button className="btn primary" onClick={submit}>Ekle</button>
    </div>
  );
}
