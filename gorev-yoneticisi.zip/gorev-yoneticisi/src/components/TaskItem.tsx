import { useState } from "react";
import { Task } from "../interfaces/Task";
interface Props { task: Task; onToggle: (id: number) => void; onUpdate: (id: number, title: string) => void; onDelete: (id: number) => void; }
export default function TaskItem({ task, onToggle, onUpdate, onDelete }: Props) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(task.title);
  const save = () => { if (text.trim()) onUpdate(task.id, text.trim()); setEditing(false); };
  return (
    <li className="card row">
      <input type="checkbox" checked={task.done} onChange={() => onToggle(task.id)} />
      {editing ? <input value={text} onChange={(e) => setText(e.target.value)} autoFocus /> : <span className={task.done ? "done" : ""}>{task.title}</span>}
      {editing ? <button className="btn primary" onClick={save}>Kaydet</button> : <button className="btn" onClick={() => setEditing(true)}>Düzenle</button>}
      <button className="btn danger" onClick={() => onDelete(task.id)}>Sil</button>
    </li>
  );
}
