import { useEffect, useState } from "react";
import { Task } from "../interfaces/Task";
import TaskForm from "../components/TaskForm";
import TaskItem from "../components/TaskItem";
const KEY = "tasks";
export default function Home() {
  const [tasks, setTasks] = useState<Task[]>(() => JSON.parse(localStorage.getItem(KEY) || "[]"));
  useEffect(() => localStorage.setItem(KEY, JSON.stringify(tasks)), [tasks]);
  const add = (title: string) => setTasks([{ id: Date.now(), title, done: false }, ...tasks]);
  const toggle = (id: number) => setTasks(tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  const update = (id: number, title: string) => setTasks(tasks.map((t) => (t.id === id ? { ...t, title } : t)));
  const remove = (id: number) => setTasks(tasks.filter((t) => t.id !== id));
  return (
    <main className="container">
      <header><h1>✅ Görev Yöneticisi</h1><p>React + TypeScript + LocalStorage ile CRUD uygulaması</p></header>
      <div className="stats"><div className="card"><b>{tasks.length}</b>Toplam</div><div className="card"><b>{tasks.filter((t) => t.done).length}</b>Tamamlanan</div></div>
      <TaskForm onAdd={add} />
      <h2>Görev Listesi</h2>
      <ul>{tasks.map((t) => <TaskItem key={t.id} task={t} onToggle={toggle} onUpdate={update} onDelete={remove} />)}</ul>
      {!tasks.length && <p className="muted">Henüz görev yok.</p>}
    </main>
  );
}
