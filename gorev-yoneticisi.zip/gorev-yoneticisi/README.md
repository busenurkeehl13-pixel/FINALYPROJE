# Görev Yöneticisi
React + TypeScript + Vite ile geliştirilmiş, LocalStorage kullanan CRUD (Ekle, Listele, Güncelle, Sil) uygulaması.

## Çalıştırma
npm install && npm run dev

## Netlify
Build command: `npm run build` — Publish directory: `dist`
